#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <cctype>
using namespace std;

// Function to convert string to lowercase for matching
string toLowerCase(string str) {
    transform(str.begin(), str.end(), str.begin(),
              [](unsigned char c){ return tolower(c); });
    return str;
}

// Function to return a random joke
string getJoke() {
    vector<string> jokes = {
        "Why don't programmers like nature? It has too many bugs.",
        "Why do Java developers wear glasses? Because they don't C#!",
        "I told my computer I needed a break, and it froze.",
        "Why was the computer cold? It left its Windows open!"
    };
    return jokes[rand() % jokes.size()];
}

// Function to return a random greeting
string getGreeting() {
    vector<string> greetings = {
        "Hello! How are you doing today?",
        "Hi there! Nice to see you.",
        "Hey! What's up?",
        "Greetings! How can I assist you?"
    };
    return greetings[rand() % greetings.size()];
}

// Function to return a random fallback response
string getFallback() {
    vector<string> responses = {
        "Hmm, I didn't quite get that.",
        "Could you rephrase that?",
        "Interesting... Tell me more!",
        "I'm still learning. Can you try asking differently?"
    };
    return responses[rand() % responses.size()];
}

int main() {
    srand(time(0)); // Seed random for jokes & greetings
    string userInput;

    cout << "Chatbot: Hello! I'm your friendly rule-based chatbot.\n";
    cout << "Chatbot: You can ask me about weather, time, jokes, or just chat. Type 'bye' to exit.\n";

    while (true) {
        cout << "\nYou: ";
        getline(cin, userInput);

        string lowerInput = toLowerCase(userInput);

        if (lowerInput == "bye" || lowerInput == "exit" || lowerInput == "quit") {
            cout << "Chatbot: Goodbye! Have a wonderful day!\n";
            break;
        }
        else if (lowerInput.find("hello") != string::npos || lowerInput.find("hi") != string::npos) {
            cout << "Chatbot: " << getGreeting() << endl;
        }
        else if (lowerInput.find("how are you") != string::npos) {
            cout << "Chatbot: I'm just a chatbot, but I'm doing great! How about you?\n";
        }
        else if (lowerInput.find("your name") != string::npos) {
            cout << "Chatbot: My name is RuleBot, a simple chatbot built with C++.\n";
        }
        else if (lowerInput.find("time") != string::npos) {
            time_t now = time(0);
            string currentTime = ctime(&now);
            if (!currentTime.empty()) currentTime.pop_back(); // remove newline
            cout << "Chatbot: The current time is " << currentTime << endl;
        }
        else if (lowerInput.find("weather") != string::npos) {
            cout << "Chatbot: I can't check the live weather, but I hope it's sunny and nice where you are!\n";
        }
        else if (lowerInput.find("joke") != string::npos) {
            cout << "Chatbot: Here's a joke for you - " << getJoke() << endl;
        }
        else if (lowerInput.find("help") != string::npos) {
            cout << "Chatbot: You can say things like 'hello', 'tell me a joke', 'what's your name', 'how are you', 'weather', or 'time'.\n";
        }
        else if (lowerInput.find("thank") != string::npos) {
            cout << "Chatbot: You're welcome! Happy to help.\n";
        }
        else if (lowerInput.find("love") != string::npos) {
            cout << "Chatbot: Aww, thank you! I love chatting with you too!\n";
        }
        else {
            cout << "Chatbot: " << getFallback() << endl;
        }
    }

    return 0;
}