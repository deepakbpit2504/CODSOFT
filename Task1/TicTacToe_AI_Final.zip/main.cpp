#include <iostream>
using namespace std;
char board[3][3] = {
    {'1','2','3'},
    {'4','5','6'},
    {'7','8','9'}
};
// Print the board
void printBoard() {
    cout << "\n";
    for (int i = 0; i < 3; i++) {
        cout << " ";
        for (int j = 0; j < 3; j++) {
            cout << board[i][j];
            if (j < 2) cout << " | ";
        }
        cout << "\n";
        if (i < 2) cout << "---+---+---\n";
    }
    cout << "\n";
}
// Check for winner
char checkWin() {
    for (int i = 0; i < 3; i++) {
        // Check rows and columns
        if (board[i][0] == board[i][1] && board[i][1] == board[i][2])
            return board[i][0];
        if (board[0][i] == board[1][i] && board[1][i] == board[2][i])
            return board[0][i];
    }
    // Check diagonals
    if (board[0][0] == board[1][1] && board[1][1] == board[2][2])
        return board[0][0];
    if (board[0][2] == board[1][1] && board[1][1] == board[2][0])
        return board[0][2];
    return ' '; // No winner
}
// Check if board is full
bool isFull() {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] != 'X' && board[i][j] != 'O')
                return false;
    return true;
}
// Minimax Algorithm
int minimax(bool isAI) {
    char winner = checkWin();
    if (winner == 'O') return 1;
    if (winner == 'X') return -1;
    if (isFull()) return 0;
    int best = isAI ? -1000 : 1000;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] != 'X' && board[i][j] != 'O') {
                char backup = board[i][j];
                board[i][j] = isAI ? 'O' : 'X';
                int score = minimax(!isAI);
                board[i][j] = backup;
                best = isAI ? max(best, score) : min(best, score);
            }
    return best;
}
// AI best move
void aiMove() {
    int bestScore = -1000;
    int bestRow = -1, bestCol = -1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (board[i][j] != 'X' && board[i][j] != 'O') {
                char backup = board[i][j];
                board[i][j] = 'O';
                int score = minimax(false);
                board[i][j] = backup;
                if (score > bestScore) {
                    bestScore = score;
                    bestRow = i;
                    bestCol = j;
                }
            }
    board[bestRow][bestCol] = 'O';
}
// user move
void playerMove() {
    int choice;
    while (true) {
        cout << "Enter your move (1-9): ";
        cin >> choice;
        if (choice < 1 || choice > 9) continue;
        int row = (choice - 1) / 3, col = (choice - 1) % 3;
        if (board[row][col] != 'X' && board[row][col] != 'O') {
            board[row][col] = 'X';
            break;
        } else {
            cout << "Cell taken. Try again.\n";
        }
    }
}

int main() {
    cout << " Tic-Tac-Toe!\nYou are X, AI is O.\n";
    printBoard();
    while (true) {
        playerMove();
        printBoard();
        if (checkWin() == 'X') {
            cout << "You win!\n";
            break;
        }
        if (isFull()) {
            cout << "Draw!\n";
            break;
        }
        cout << "AI's turn:\n";
        aiMove();
        printBoard();
        if (checkWin() == 'O') {
            cout << "AI wins!\n";
            break;
        }
        if (isFull()) {
            cout << "Draw!\n";
            break;
        }
    }

    return 0;
}
